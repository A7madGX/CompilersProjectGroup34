from ast import Add
from cProfile import label
import re
from typing import Iterable
from pyvis.network import Network
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Tokens:

identifier = "[a-zA-Z][a-zA-Z0-9]*"
number = "[0-9]+"
add = "\+"
minus = "\-"
mul = "\*"
div = "\/"
left_p = "\("
right_p = "\)"

OP = f"[+-/*]"

UNREC = f"[0-9]+[a-zA-Z]+[0-9]*|\w*[^a-zA-Z0-9\+\-\*\/\(\)\s]+\w*|{OP}{OP}+"

Types = f"({UNREC}|{identifier}|{number}|{add}|{minus}|{mul}|{div}|{left_p}|{right_p})"

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Parse Table:

EXP    = [["TERM", "EXP_"], ["TERM", "EXP_"], "ERROR", "ERROR", "ERROR", "ERROR", ["TERM", "EXP_"], "ERROR", "ERROR"]
EXP_   = ["ERROR", "ERROR", ["ADDOP", "TERM", "EXP_"], ["ADDOP", "TERM", "EXP_"], "ERROR", "ERROR", "ERROR", "EPSILON", "EPSILON"]
ADDOP  = ["ERROR", "ERROR", "+", "-", "ERROR", "ERROR", "ERROR", "ERROR", "ERROR" ]
TERM   = [["FACTOR", "TERM_"], ["FACTOR", "TERM_"], "ERROR", "ERROR", "ERROR", "ERROR", ["FACTOR", "TERM_"], "ERROR", "ERROR"]
TERM_  = ["ERROR", "ERROR", "EPSILON", "EPSILON", ["MULLOP", "FACTOR", "TERM_"], ["MULLOP", "FACTOR", "TERM_"], "ERROR", "EPSILON", "EPSILON"]
MULLOP = ["ERROR", "ERROR", "ERROR", "ERROR", "*", "/", "ERROR", "ERROR", "ERROR",]
FACTOR = ["identifier", "number", "ERROR", "ERROR", "ERROR", "ERROR", ["(", "EXP", ")"], "ERROR", "ERROR",]

Parsing_table = {
    "EXP": EXP,
    "EXP_": EXP_,
    "ADDOP": ADDOP,
    "TERM": TERM,
    "TERM_": TERM_,
    "MULLOP": MULLOP,
    "FACTOR": FACTOR
}


print("-------------------------------------------------------------------------------------------")
for key, value in Parsing_table.items():
    print(key, ":", value)
print("-------------------------------------------------------------------------------------------")

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Stack:

stack = ["$", "EXP"]

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Input:



text = "x + +"

text_to_list = re.findall(Types, text)
print(text_to_list)

tokens = list()
unrec = list()

for i in text_to_list:
    if re.search(f"^{UNREC}$", i):
        unrec.append(i)
    elif re.search(identifier, i):
        tokens.append("identifier")
    elif re.search(number, i):
        tokens.append("number") 
    elif re.search(add, i):
        tokens.append("+")
    elif re.search(minus, i):
        tokens.append("-")
    elif re.search(mul, i):
        tokens.append("*")
    elif re.search(div, i):
        tokens.append("/")
    elif re.search(left_p, i):
        tokens.append("(")
    elif re.search(right_p, i):
        tokens.append(")")
    

tokens.append("$")

print(tokens)
print(unrec)                # if unrec is not empty then output should be error abl mat3ml parsing 7ata
print("--------------------------------------------------")

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Parsing:

def getIndex(token):
    if token == "identifier":
        return 0
    elif token == "number":
        return 1    
    elif token == "+":
        return 2
    elif token == "-":
        return 3
    elif token == "*":
        return 4
    elif token == "/":
        return 5
    elif token == "(":
        return 6
    elif token == ")":
        return 7
    elif token == "$":
        return 8
    

# parseTree part ------------------------------------------------------------
Nodes    = ["EXP"]
Edges    = []
id_edges = []
id_stack = [0]
id_nodes = [0]
ids = 1
idn = 1
#----------------------------------------------------------------------------


leaves = ["EPSILON", "+", "-", "*", "/", "(", ")", "$", "number", "identifier"]
i = 0
error_message = None

if unrec:
    print("--------------------------------------------------")
    print("Syntax is Incorrect: Lexical Analyzer")
    print("UnRecognized tokens:", unrec)
else:
    while(stack[-1] != "$"):
        last_element_Stack = stack.pop()
        
        # parseTree part ------------------------------------------------------------
        last_number = id_stack.pop()
        id_nodes_last_index = -1
        #----------------------------------------------------------------------------

        if last_element_Stack not in leaves:
            parent_node = last_element_Stack
            
            # parseTree part ------------------------------------------------------------
            pn = last_number
            #----------------------------------------------------------------------------

        if tokens[i] == "$" and last_element_Stack == ")":
            error_message = "Unbalanced Parenthesis"
            break

        if last_element_Stack == tokens[i]:
            i = i + 1
        else:
            if isinstance(Parsing_table.get(last_element_Stack)[getIndex(tokens[i])], list):
                
                # parseTree part -----------------------------------------------------------
                for k in Parsing_table.get(last_element_Stack)[getIndex(tokens[i])]:                                      
                    Nodes.append(k)
                    Edges.append([parent_node, Nodes[-1]])
                    id_nodes.append(idn)
                    id_edges.append([pn, idn])
                    idn = idn + 1
                #---------------------------------------------------------------------------

                for j in reversed(Parsing_table.get(last_element_Stack)[getIndex(tokens[i])]):
                    stack.append(j)

                    # parseTree part -----------------------------------------------------------
                    id_stack.append(id_nodes[id_nodes_last_index])
                    id_nodes_last_index = id_nodes_last_index - 1
                    ids = ids + 1
                    #---------------------------------------------------------------------------

            
            else:
                if Parsing_table.get(last_element_Stack)[getIndex(tokens[i])] == "EPSILON":

                    # parseTree part -----------------------------------------------------------
                    Nodes.append(Parsing_table.get(last_element_Stack)[getIndex(tokens[i])])
                    Edges.append([parent_node, Nodes[-1]])
                    id_nodes.append(idn)
                    id_edges.append([pn, idn])
                    idn = idn + 1
                    ids = ids + 1
                    #---------------------------------------------------------------------------
                    if (re.search(identifier, tokens[i]) or re.search(number, tokens[i])) and stack[-1] == "$":
                        error_message = "Missing Operation(s)"
                    elif tokens[i] in "+-/*" and stack[-1] == "$":                    
                        error_message = "Missing Operand(s)"
                    elif tokens[i] in "()" and stack[-1] == "$":
                        error_message = "Unbalanced Parenthesis"
                    continue

                elif Parsing_table.get(last_element_Stack)[getIndex(tokens[i])] == "ERROR":
                    if re.search(identifier, tokens[i]) or re.search(number, tokens[i]):
                        error_message = "Missing Operation(s)"
                    elif tokens[i-1] in "+-/*":                    
                        error_message = "Missing Operand(s)"
                    elif tokens[i-1] in "()":
                        error_message = "Unbalanced Parenthesis"
                    break

                stack.append(Parsing_table.get(last_element_Stack)[getIndex(tokens[i])])
   
                # parseTree part -----------------------------------------------------------
                Nodes.append(Parsing_table.get(last_element_Stack)[getIndex(tokens[i])])
                Edges.append([parent_node, Nodes[-1]])
                id_stack.append(ids)
                ids = ids + 1
                id_nodes.append(idn)
                id_edges.append([pn, idn])
                idn = idn + 1
                #---------------------------------------------------------------------------


    if tokens[i] == "$" and stack[-1] == "$":
        print("--------------------------------------------------")
        print("Syntax is Correct")
        print("--------------------------------------------------")
        print(Nodes)
        print("--------------------------------------------------")
        print(Edges)
        print("--------------------------------------------------")
        print(id_nodes)
        print(id_edges)
    else:
        print("Syntax is Incorrect: Parser")
        print(error_message)
        
#-------------------------------------------------------------------------------------------------------------------------------------
# ParseTree
print("-------------------------------------------------------------------------------------")


parseTree = Network('710px', '1520px')

parseTree.add_nodes(id_nodes, label= Nodes, color= ['#162347' for i in range(len(Nodes))], shape= ["dot" for i in range(len(Nodes))])
parseTree.add_edges(id_edges)


parseTree.set_options(
        """   
            {"layout": {
                    "hierarchical": {
                        "sortMethod": "directed"
                    }
                }
        }
        """
        )
if tokens[i] == "$" and stack[-1] == "$":
    parseTree.show("Compilers\\ParseTree.html")

#-------------------------------------------------------------------------------------------------------------------------------------
# Syntax Tree

if tokens[i] == "$" and stack[-1] == "$":

    node_leaves = list()
    for s in Nodes:
        if s in "+-*/identifiernumber":
            node_leaves.append(s)

    constant = 0
    syntax_tree_nodes = list()

    while constant < len(text_to_list):
            if re.search(identifier, text_to_list[constant]):
                syntax_tree_nodes.append(text_to_list[constant])
            elif re.search(number, text_to_list[constant]):
                syntax_tree_nodes.append(text_to_list[constant]) 
            elif re.search(add, text_to_list[constant]):
                syntax_tree_nodes.append(text_to_list[constant])
            elif re.search(minus, text_to_list[constant]):
                syntax_tree_nodes.append(text_to_list[constant])
            elif re.search(mul, text_to_list[constant]):
                syntax_tree_nodes.append(text_to_list[constant])
            elif re.search(div, text_to_list[constant]):
                syntax_tree_nodes.append(text_to_list[constant])
            constant = constant + 1


    node_precedence = [[0 for q in range(2)] for i in range(len(node_leaves))]
    kg = 0
    add_counter = 0
    mul_counter = 0
    while(kg < len(node_leaves)):
        if node_leaves[kg] not in "*/+-":
            kg = kg + 1
            continue
        if node_leaves[kg] in "+-":
            node_precedence[kg][0] = 1
            node_precedence[kg][1] = add_counter
            add_counter = add_counter + 1
        elif node_leaves[kg] in "*/":
            node_precedence[kg][0] = 2
            node_precedence[kg][1] = mul_counter
            mul_counter = mul_counter + 1
        kg = kg + 1

    leaves_id = [i for i in range(len(node_leaves))]
    print(leaves_id)


    syntax_tree = Network('710px', '1520px')
    syntax_tree.add_nodes(leaves_id, label= syntax_tree_nodes)

    n = len(node_precedence)
    syntax_tree_edges = list() 

    print(node_precedence)

    while len(leaves_id) > 1:
        index_max_precedence = 0
        index_ = 0
        while index_ < len(node_precedence):
            if node_precedence[index_][0] > node_precedence[index_max_precedence][0]:
                index_max_precedence = index_
            elif node_precedence[index_][0] == node_precedence[index_max_precedence][0]:
                if node_precedence[index_][1] < node_precedence[index_max_precedence][1]:
                    index_max_precedence = index_

            index_ = index_ + 1

        syntax_tree.add_edge(leaves_id[index_max_precedence], leaves_id[index_max_precedence-1])
        syntax_tree_edges.append([leaves_id[index_max_precedence], leaves_id[index_max_precedence-1]])

        syntax_tree.add_edge(leaves_id[index_max_precedence], leaves_id[index_max_precedence+1])
        syntax_tree_edges.append([leaves_id[index_max_precedence], leaves_id[index_max_precedence+1]])

        
        leaves_id.pop(index_max_precedence-1)
        leaves_id.pop(index_max_precedence)

        node_precedence[index_max_precedence][0] = 0
        node_precedence[index_max_precedence][1] = 0
        node_precedence.pop(index_max_precedence-1)
        node_precedence.pop(index_max_precedence)


    syntax_tree.set_options(
            """   
                {"layout": {
                        "hierarchical": {
                            "sortMethod": "directed"
                        }
                    }
            }
            """
            )

    syntax_tree.show("Compilers\\SyntaxTree.html")

    print(syntax_tree_edges)
    print(node_leaves)
    print(leaves_id)
    print(node_precedence)
    print("-------------------------------------------------------------------------------------")