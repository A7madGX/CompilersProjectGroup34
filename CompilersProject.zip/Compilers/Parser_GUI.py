import sys
from tkinter.tix import Tree
from PyQt5 import QtWidgets, QtGui
from PyQt5.QtWidgets import QDialog, QApplication
from PyQt5.uic import loadUi
from matplotlib.pyplot import step
from ast import Add
from cProfile import label
import re
from typing import Iterable
from pyvis.network import Network

class Menu(QDialog):
    def __init__(self):
        super(Menu, self).__init__()
        loadUi("Compilers\\menu.ui", self)
        self.stepsButton.clicked.connect(self.stepsButtonClicked)
        self.parseButton.clicked.connect(self.parseButtonClicked)

    def stepsButtonClicked(self):
        AllWidgets.setCurrentIndex(AllWidgets.currentIndex() + 1)
    
    def parseButtonClicked(self):
        AllWidgets.setCurrentIndex(AllWidgets.currentIndex() + 2)




class Steps(QDialog):
    def __init__(self):
        super(Steps, self).__init__()
        loadUi("Compilers\\steps.ui", self)
        self.okButton.clicked.connect(self.okButtonClicked)
        self.backButton.clicked.connect(self.backButtonClicked)

    def backButtonClicked(self):
        AllWidgets.setCurrentIndex(AllWidgets.currentIndex() - 1)
        
    def okButtonClicked(self):
        text = self.stepBox.currentText()
        if text == "CFG":
            self.photo.setPixmap(QtGui.QPixmap("Compilers\\CFG.png"))
        elif text == "First/Follow Table":
            self.photo.setPixmap(QtGui.QPixmap("Compilers\\FirstFollowTable.png"))
        elif text == "Parse Table":
            self.photo.setPixmap(QtGui.QPixmap("Compilers\\ParseTable.png"))
    



class Parse(QDialog):
    parseTreeStack = list()
    currentIndexParse = -1
    syntaxTreeStack = list()
    currentIndexSyntax = -1
    def __init__(self):
        super(Parse, self).__init__()
        loadUi("Compilers\\parse.ui", self)
        self.back2Button.clicked.connect(self.backclicked)
        self.okInputButton.clicked.connect(self.okInputclicked)
        self.parseTreeButton.clicked.connect(self.parseTreeclicked)
        self.syntaxTreeButton.clicked.connect(self.syntaxTreeclicked)
        self.clearButton.clicked.connect(self.clearButtonclicked)

    def backclicked(self):
        AllWidgets.setCurrentIndex(AllWidgets.currentIndex() - 2)
    
    def clearButtonclicked(self):
        self.inputExpression.setText(None)
        self.lexicalOutputLabel.setText(None)
        self.lexicalErrorsOutput.setText(None)
        self.ParserOutputLabel.setText(None)
        self.ParserErrorsOutput.setText(None)

    def okInputclicked(self):

        #------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        # Tokens:

        identifier = "[a-zA-Z][a-zA-Z0-9]*"
        number = "[0-9]+"
        add = "\+"
        minus = "\-"
        mul = "\*"
        div = "\/"
        left_p = "\("
        right_p = "\)"

        OP = f"[+-/*]"

        UNREC = f"[0-9]+[a-zA-Z]+[0-9]*|\w*[^a-zA-Z0-9\+\-\*\/\(\)\s]+\w*|{OP}{OP}+"

        Types = f"({UNREC}|{identifier}|{number}|{add}|{minus}|{mul}|{div}|{left_p}|{right_p})"

        #------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        # Parse Table:

        EXP    = [["TERM", "EXP_"], ["TERM", "EXP_"], "ERROR", "ERROR", "ERROR", "ERROR", ["TERM", "EXP_"], "ERROR", "ERROR"]
        EXP_   = ["ERROR", "ERROR", ["ADDOP", "TERM", "EXP_"], ["ADDOP", "TERM", "EXP_"], "ERROR", "ERROR", "ERROR", "EPSILON", "EPSILON"]
        ADDOP  = ["ERROR", "ERROR", "+", "-", "ERROR", "ERROR", "ERROR", "ERROR", "ERROR" ]
        TERM   = [["FACTOR", "TERM_"], ["FACTOR", "TERM_"], "ERROR", "ERROR", "ERROR", "ERROR", ["FACTOR", "TERM_"], "ERROR", "ERROR"]
        TERM_  = ["ERROR", "ERROR", "EPSILON", "EPSILON", ["MULLOP", "FACTOR", "TERM_"], ["MULLOP", "FACTOR", "TERM_"], "ERROR", "EPSILON", "EPSILON"]
        MULLOP = ["ERROR", "ERROR", "ERROR", "ERROR", "*", "/", "ERROR", "ERROR", "ERROR",]
        FACTOR = ["identifier", "number", "ERROR", "ERROR", "ERROR", "ERROR", ["(", "EXP", ")"], "ERROR", "ERROR",]

        Parsing_table = {
            "EXP": EXP,
            "EXP_": EXP_,
            "ADDOP": ADDOP,
            "TERM": TERM,
            "TERM_": TERM_,
            "MULLOP": MULLOP,
            "FACTOR": FACTOR
        }
        print("-------------------------------------------------------------------------------------------")
        for key, value in Parsing_table.items():
            print(key, ":", value)
        print("-------------------------------------------------------------------------------------------")

        #------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        # Stack:

        stack = ["$", "EXP"]

        #-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
        # Input:

        text = self.inputExpression.text()

        text_to_list = re.findall(Types, text)
        print(text_to_list)

        tokens = list()
        unrec = list()

        for i in text_to_list:
            if re.search(f"^{UNREC}$", i):
                unrec.append(i)
            elif re.search(identifier, i):
                tokens.append("identifier")
            elif re.search(number, i):
                tokens.append("number") 
            elif re.search(add, i):
                tokens.append("+")
            elif re.search(minus, i):
                tokens.append("-")
            elif re.search(mul, i):
                tokens.append("*")
            elif re.search(div, i):
                tokens.append("/")
            elif re.search(left_p, i):
                tokens.append("(")
            elif re.search(right_p, i):
                tokens.append(")")
            

        tokens.append("$")

        print(tokens)
        print(unrec)                # if unrec is not empty then output should be error abl mat3ml parsing 7ata
        print("--------------------------------------------------")

        #-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
        # Parsing:

        def getIndex(token):
            if token == "identifier":
                return 0
            elif token == "number":
                return 1    
            elif token == "+":
                return 2
            elif token == "-":
                return 3
            elif token == "*":
                return 4
            elif token == "/":
                return 5
            elif token == "(":
                return 6
            elif token == ")":
                return 7
            elif token == "$":
                return 8
            

        # parseTree part ------------------------------------------------------------
        Nodes    = ["EXP"]
        Edges    = []
        id_edges = []
        id_stack = [0]
        id_nodes = [0]
        ids = 1
        idn = 1
        #----------------------------------------------------------------------------


        leaves = ["EPSILON", "+", "-", "*", "/", "(", ")", "$", "number", "identifier"]
        i = 0
        error_message = None

        if unrec:
            print("--------------------------------------------------")
            print("Syntax is Incorrect: Lexical Analyzer")
            self.lexicalOutputLabel.setText("UnAccepted")
            print("UnRecognized tokens:", unrec)
            self.lexicalErrorsOutput.setText(str(unrec))
        else:
            self.lexicalOutputLabel.setText("Accepted")
            while(stack[-1] != "$"):
                last_element_Stack = stack.pop()
                
                # parseTree part ------------------------------------------------------------
                last_number = id_stack.pop()
                id_nodes_last_index = -1
                #----------------------------------------------------------------------------

                if last_element_Stack not in leaves:
                    parent_node = last_element_Stack
                    
                    # parseTree part ------------------------------------------------------------
                    pn = last_number
                    #----------------------------------------------------------------------------

                if tokens[i] == "$" and last_element_Stack == ")":
                    error_message = "Unbalanced Parenthesis"
                    break

                if last_element_Stack == tokens[i]:
                    i = i + 1
                else:
                    if isinstance(Parsing_table.get(last_element_Stack)[getIndex(tokens[i])], list):
                        
                        # parseTree part -----------------------------------------------------------
                        for k in Parsing_table.get(last_element_Stack)[getIndex(tokens[i])]:                                      
                            Nodes.append(k)
                            Edges.append([parent_node, Nodes[-1]])
                            id_nodes.append(idn)
                            id_edges.append([pn, idn])
                            idn = idn + 1
                        #---------------------------------------------------------------------------

                        for j in reversed(Parsing_table.get(last_element_Stack)[getIndex(tokens[i])]):
                            stack.append(j)

                            # parseTree part -----------------------------------------------------------
                            id_stack.append(id_nodes[id_nodes_last_index])
                            id_nodes_last_index = id_nodes_last_index - 1
                            ids = ids + 1
                            #---------------------------------------------------------------------------

                    
                    else:
                        if Parsing_table.get(last_element_Stack)[getIndex(tokens[i])] == "EPSILON":

                            # parseTree part -----------------------------------------------------------
                            Nodes.append(Parsing_table.get(last_element_Stack)[getIndex(tokens[i])])
                            Edges.append([parent_node, Nodes[-1]])
                            id_nodes.append(idn)
                            id_edges.append([pn, idn])
                            idn = idn + 1
                            ids = ids + 1
                            #---------------------------------------------------------------------------
                            if (re.search(identifier, tokens[i]) or re.search(number, tokens[i])) and stack[-1] == "$":
                                error_message = "Missing Operation(s)"
                            elif tokens[i] in "+-/*" and stack[-1] == "$":                    
                                error_message = "Missing Operand(s)"
                            elif tokens[i] in "()" and stack[-1] == "$":
                                error_message = "Unbalanced Parenthesis"
                            continue

                        elif Parsing_table.get(last_element_Stack)[getIndex(tokens[i])] == "ERROR":
                            if re.search(identifier, tokens[i]) or re.search(number, tokens[i]):
                                error_message = "Missing Operation(s)"
                            elif tokens[i-1] in "+-/*":                    
                                error_message = "Missing Operand(s)"
                            elif tokens[i-1] in "()":
                                error_message = "Unbalanced Parenthesis"
                            break

                        stack.append(Parsing_table.get(last_element_Stack)[getIndex(tokens[i])])
        
                        # parseTree part -----------------------------------------------------------
                        Nodes.append(Parsing_table.get(last_element_Stack)[getIndex(tokens[i])])
                        Edges.append([parent_node, Nodes[-1]])
                        id_stack.append(ids)
                        ids = ids + 1
                        id_nodes.append(idn)
                        id_edges.append([pn, idn])
                        idn = idn + 1
                        #---------------------------------------------------------------------------


            if tokens[i] == "$" and stack[-1] == "$":
                print("--------------------------------------------------")
                print("Syntax is Correct")
                self.ParserOutputLabel.setText("Accepted")
                print("--------------------------------------------------")
                print(Nodes)
                print("--------------------------------------------------")
                print(Edges)
                print("--------------------------------------------------")
                print(id_nodes)
                print(id_edges)
            else:
                print("Syntax is Incorrect: Parser")
                self.ParserOutputLabel.setText("UnAccepted")
                print(error_message)
                self.ParserErrorsOutput.setText(error_message)
                
        #-------------------------------------------------------------------------------------------------------------------------------------
        # ParseTree
        print("-------------------------------------------------------------------------------------")

        parseTree = Network('710px', '1520px')
        parseTree.set_options(
                """   
                    {"layout": {
                            "hierarchical": {
                                "sortMethod": "directed"
                            }
                        }
                }
                """
                )
        self.parseTreeStack.append(parseTree)
        self.currentIndexParse += 1

        parseTree.add_nodes(id_nodes, label= Nodes, color= ['#162347' for i in range(len(Nodes))], shape= ["dot" for i in range(len(Nodes))])
        parseTree.add_edges(id_edges)


        #-------------------------------------------------------------------------------------------------------------------------------------
        # Syntax Tree

        if tokens[i] == "$" and stack[-1] == "$":

            node_leaves = list()
            for s in Nodes:
                if s in "+-*/identifiernumber":
                    node_leaves.append(s)

            constant = 0
            syntax_tree_nodes = list()

            while constant < len(text_to_list):
                    if re.search(identifier, text_to_list[constant]):
                        syntax_tree_nodes.append(text_to_list[constant])
                    elif re.search(number, text_to_list[constant]):
                        syntax_tree_nodes.append(text_to_list[constant]) 
                    elif re.search(add, text_to_list[constant]):
                        syntax_tree_nodes.append(text_to_list[constant])
                    elif re.search(minus, text_to_list[constant]):
                        syntax_tree_nodes.append(text_to_list[constant])
                    elif re.search(mul, text_to_list[constant]):
                        syntax_tree_nodes.append(text_to_list[constant])
                    elif re.search(div, text_to_list[constant]):
                        syntax_tree_nodes.append(text_to_list[constant])
                    constant = constant + 1


            node_precedence = [[0 for q in range(2)] for i in range(len(node_leaves))]
            kg = 0
            add_counter = 0
            mul_counter = 0
            while(kg < len(node_leaves)):
                if node_leaves[kg] not in "*/+-":
                    kg = kg + 1
                    continue
                if node_leaves[kg] in "+-":
                    node_precedence[kg][0] = 1
                    node_precedence[kg][1] = add_counter
                    add_counter = add_counter + 1
                elif node_leaves[kg] in "*/":
                    node_precedence[kg][0] = 2
                    node_precedence[kg][1] = mul_counter
                    mul_counter = mul_counter + 1
                kg = kg + 1

            leaves_id = [i for i in range(len(node_leaves))]
            print(leaves_id)

            syntax_tree = Network('710px', '1520px')
            syntax_tree.set_options(
                                """   
                                    {"layout": {
                                            "hierarchical": {
                                                "sortMethod": "directed"
                                            }
                                        }
                                }
                                """
                                )

            self.syntaxTreeStack.append(syntax_tree)
            self.currentIndexSyntax += 1
            
            syntax_tree.add_nodes(leaves_id, label= syntax_tree_nodes)

            n = len(node_precedence)
            syntax_tree_edges = list() 

            print(node_precedence)

            while len(leaves_id) > 1:
                index_max_precedence = 0
                index_ = 0
                while index_ < len(node_precedence):
                    if node_precedence[index_][0] > node_precedence[index_max_precedence][0]:
                        index_max_precedence = index_
                    elif node_precedence[index_][0] == node_precedence[index_max_precedence][0]:
                        if node_precedence[index_][1] < node_precedence[index_max_precedence][1]:
                            index_max_precedence = index_

                    index_ = index_ + 1

                syntax_tree.add_edge(leaves_id[index_max_precedence], leaves_id[index_max_precedence-1])
                syntax_tree_edges.append([leaves_id[index_max_precedence], leaves_id[index_max_precedence-1]])

                syntax_tree.add_edge(leaves_id[index_max_precedence], leaves_id[index_max_precedence+1])
                syntax_tree_edges.append([leaves_id[index_max_precedence], leaves_id[index_max_precedence+1]])

                
                leaves_id.pop(index_max_precedence-1)
                leaves_id.pop(index_max_precedence)

                node_precedence[index_max_precedence][0] = 0
                node_precedence[index_max_precedence][1] = 0
                node_precedence.pop(index_max_precedence-1)
                node_precedence.pop(index_max_precedence)


            

            print(syntax_tree_edges)
            print(node_leaves)
            print(leaves_id)
            print(node_precedence)
            print("-------------------------------------------------------------------------------------")

    def parseTreeclicked(self):
        if self.parseTreeStack:
            parseTree = self.parseTreeStack[self.currentIndexParse]
            if self.lexicalOutputLabel.text() == "Accepted" and self.ParserOutputLabel.text() == "Accepted":
                parseTree.show("Compilers\\ParseTree.html")

    def syntaxTreeclicked(self):
        if self.syntaxTreeStack:
            syntax_tree = self.syntaxTreeStack[self.currentIndexSyntax]
            if self.lexicalOutputLabel.text() == "Accepted" and self.ParserOutputLabel.text() == "Accepted":
                syntax_tree.show("Compilers\\SyntaxTree.html")




app = QApplication(sys.argv)
mainWindow = Menu()
steps = Steps()
parsing = Parse()

AllWidgets = QtWidgets.QStackedWidget()
AllWidgets.addWidget(mainWindow)
AllWidgets.addWidget(steps)
AllWidgets.addWidget(parsing)
AllWidgets.setCurrentIndex(0)
AllWidgets.setFixedWidth(850)
AllWidgets.setFixedHeight(800)

AllWidgets.show()
app.exec_()